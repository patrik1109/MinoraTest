package com.example.Minora;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MinoraApplicationTests {

	@Test
	void contextLoads() {
	}

}
